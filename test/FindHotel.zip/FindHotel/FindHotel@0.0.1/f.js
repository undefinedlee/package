// FindHotel@0.0.1/views/home/pic/logo@2x.png
loader.define("FindHotel@0.0.1", "views/home/pic/logo@2x.png", "f", function(require, global, __project, __filename, __dirname, __base, __pixel_ratio){
	"use strict";
	
	return [
		// views/home/pic/logo@2x.png
		function(__inner_require__, exports, module){
			var images = require("FindHotel@0.0.1/__base64_image_sprite_mod_id__");
			module.exports = ["", images["e63768e0149ab844c2828394aa5ce5df54832a22.png"], images["907950f3ce31a10e53ddb3b3da9a2cb55f214792.png"], images["907950f3ce31a10e53ddb3b3da9a2cb55f214792.png"]][__pixel_ratio];
		}
	];
});
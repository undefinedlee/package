loader.version("enjoy-common-support@0.0.13", {
	"dist/index.js": "0"
});
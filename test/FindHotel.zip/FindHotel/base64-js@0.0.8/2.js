loader.version("base64-js@0.0.8", {
	"lib/b64.js": "0"
});
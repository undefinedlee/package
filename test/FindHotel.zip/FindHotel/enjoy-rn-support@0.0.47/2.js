loader.version("enjoy-rn-support@0.0.47", {
	"dist/index.js": "0"
});
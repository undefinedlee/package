loader.version("react-deep-force-update@1", {
	"lib/index.js": "0"
});
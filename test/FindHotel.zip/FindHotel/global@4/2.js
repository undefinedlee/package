loader.version("global@4", {
	"window.js": "0"
});
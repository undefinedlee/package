loader.version("react-timer-mixin@0.13", {
	"TimerMixin.js": "0"
});
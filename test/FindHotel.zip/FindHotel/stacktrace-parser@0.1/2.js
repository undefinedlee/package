loader.version("stacktrace-parser@0.1", {
	"index.js": "0"
});
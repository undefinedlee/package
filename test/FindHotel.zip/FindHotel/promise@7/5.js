loader.version("promise@7", {
	"setimmediate/core.js": "3",
	"setimmediate/done.js": "1",
	"setimmediate/es6-extensions.js": "0",
	"setimmediate/rejection-tracking.js": "2"
});
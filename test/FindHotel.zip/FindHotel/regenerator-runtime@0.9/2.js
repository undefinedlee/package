loader.version("regenerator-runtime@0.9", {
	"runtime.js": "0"
});
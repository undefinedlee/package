loader.version("immutable@3", {
	"dist/immutable.js": "0"
});
// react-native@0.21/Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/fbjs/lib/emptyObject.js
loader.define("react-native@0.21", "Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/fbjs/lib/emptyObject.js", "o", function (require, global, __project, __filename, __dirname, __base, __pixel_ratio) {

	return [
	// Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/fbjs/lib/emptyObject.js
	function (__inner_require__, exports, module) {
		var emptyObject = {};

		if (process.env.NODE_ENV !== 'production') {
			Object.freeze(emptyObject);
		}

		module.exports = emptyObject;
	}];
});
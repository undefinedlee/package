// react-native@0.21/Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/react/lib/ReactCurrentOwner.js
loader.define("react-native@0.21", "Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/react/lib/ReactCurrentOwner.js", "6", function (require, global, __project, __filename, __dirname, __base, __pixel_ratio) {

	return [
	// Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/react/lib/ReactCurrentOwner.js
	function (__inner_require__, exports, module) {
		var ReactCurrentOwner = {

			current: null };

		module.exports = ReactCurrentOwner;
	}];
});
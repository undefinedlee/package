// react-native@0.21/Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/react/lib/ReactPropTypeLocations.js
loader.define("react-native@0.21", "Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/react/lib/ReactPropTypeLocations.js", "g", function (require, global, __project, __filename, __dirname, __base, __pixel_ratio) {

	return [
	// Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/react/lib/ReactPropTypeLocations.js
	function (__inner_require__, exports, module) {
		var keyMirror = require('react-native@0.21/Users/lifan/work-elong/enjoy/examples/FindHotel/rn/node_modules/fbjs/lib/keyMirror.js');

		var ReactPropTypeLocations = keyMirror({
			prop: null,
			context: null,
			childContext: null });

		module.exports = ReactPropTypeLocations;
	}];
});
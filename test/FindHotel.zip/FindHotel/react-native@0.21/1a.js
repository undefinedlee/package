// react-native@0.21/Libraries/Utilities/ErrorUtils.js
loader.define("react-native@0.21", "Libraries/Utilities/ErrorUtils.js", "1a", function (require, global, __project, __filename, __dirname, __base, __pixel_ratio) {

	return [
	// Libraries/Utilities/ErrorUtils.js
	function (__inner_require__, exports, module) {
		var GLOBAL = this;

		module.exports = GLOBAL.ErrorUtils;
	}];
});
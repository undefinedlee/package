// react-native@0.21/Libraries/Utilities/Platform.ios.js
loader.define("react-native@0.21", "Libraries/Utilities/Platform.ios.js", "1d", function (require, global, __project, __filename, __dirname, __base, __pixel_ratio) {

	return [
	// Libraries/Utilities/Platform.ios.js
	function (__inner_require__, exports, module) {
		var Platform = {
			OS: 'ios' };

		module.exports = Platform;
	}];
});
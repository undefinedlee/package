loader.version("react-proxy@1", {
	"modules/index.js": "0"
});
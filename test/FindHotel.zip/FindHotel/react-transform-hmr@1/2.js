loader.version("react-transform-hmr@1", {
	"lib/index.js": "0"
});
loader.version("event-target-shim@1", {
	"lib/event-target.js": "0"
});
loader.version("regenerator@0.8", {
	"runtime.js": "0"
});
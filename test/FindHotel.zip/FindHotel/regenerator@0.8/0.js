// regenerator@0.8/runtime.js
loader.define("regenerator@0.8", "runtime.js", "0", function(require, global, __project, __filename, __dirname, __base, __pixel_ratio){
	"use strict";
	
	return [
		// runtime.js
		function(__inner_require__, exports, module){
			console.warn("The regenerator/runtime module is deprecated; " + "please import regenerator-runtime/runtime instead.");
			
			module.exports = require("regenerator-runtime@0.9/runtime.js");
		}
	];
});
loader.version("art@0.10", {
	"core/class.js": "2",
	"core/color.js": "0",
	"core/path.js": "3",
	"core/transform.js": "1"
});